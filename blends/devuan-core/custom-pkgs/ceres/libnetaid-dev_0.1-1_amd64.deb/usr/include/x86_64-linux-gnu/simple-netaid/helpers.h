 /*
  * helpers.h
  * Copyright (C) Aitor Cuadrado Zubizarreta <aitor_czr@gnuinos.org>
  * 
  * simple-netaid is free software: you can redistribute it and/or modify it
  * under the terms of the GNU General Public License as published by the
  * Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  * 
  * simple-netaid is distributed in the hope that it will be useful, but
  * WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  * See the GNU General Public License for more details.
  * 
  * You should have received a copy of the GNU General Public License along
  * with this program.  If not, see <http://www.gnu.org/licenses/>.
  * 
  * See the COPYING file.
  */

#ifndef __HELPERS_H__
#define __HELPERS_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdbool.h>
#include <inttypes.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <signal.h>

// Forward declaration:
struct sbuf;

void print_active_wifis(const char*);
short ifquery(const char*);
void ifup(const char*);
void ifdown(const char*);
void kill_all_processes();
void disconnect(const char *ifname);
void wired_connection(const char*);
void wireless_connection(const char*, const char*, const char*, const char*);
void wpa_passphrase(const char*, const char*, const char*);
void wpa_supplicant(const char*, const char*);
short file_exists(const char*);

#endif /* __HELPERS_H__ */
