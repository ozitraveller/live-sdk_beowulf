/*
 * sbuf.h
 * Simple C string buffer implementatioun.
 *
 * Copyright Johan Malm 2016
 *
 * The buffer is a byte array which is at least (len + 1) bytes in size.
 * The sbuf functions are designed too maintain/add '\0' at the end,
 * allowing the buffer to be used be used as a C string
 * (i.e. buf[len] == 0).
 *
 * sbuf_init allocates one byte so that the buffer can always be safely:
 *	- assumed to be a valid C string (i.e. buf != NULL)
 *	- freed (i.e. buf must not to point to memory on the stack)
 *
 * Example life cycle:
 *	struct sbuf s;
 *	sbuf_init(&s);
 *	sbuf_addch(&s, 'F');
 *	sbuf_addstr(&s, "oo");
 *	printf("%s\n", s.buf);
 *	free(s.buf);
 */

#ifndef __SBUF_H__
#define __SBUF_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct sbuf {
	char *buf;
	int bufsiz;
	int len;
};

void sbuf_init(struct sbuf*);
void sbuf_addch(struct sbuf*, char);
void sbuf_addstr(struct sbuf*, const char*);
void sbuf_concat(struct sbuf*, int, ...);
void sbuf_random(struct sbuf*, const int);

#endif /* __SBUF_H__ */
